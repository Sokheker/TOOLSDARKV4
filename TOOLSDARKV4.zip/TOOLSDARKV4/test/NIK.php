<?php
error_reporting(0);
system('clear');
include ('rumus.php');
menu();